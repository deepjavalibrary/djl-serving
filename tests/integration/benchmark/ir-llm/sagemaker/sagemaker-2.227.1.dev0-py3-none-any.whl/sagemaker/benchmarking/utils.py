# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Holds the InferenceBenchmark class."""
from __future__ import absolute_import

from typing import Optional
from sagemaker import Session


def get_benchmarks_output_csv(
    job_name: str,
    session: Session,
    download: Optional[bool] = False,
    local_path: Optional[str] = ".",
) -> str:
    """Returns S3 location of the job's benchmark_output_results_config location.

    Args:
        job_name (str): The name of the job to download the metrics CSV for.
        session (Session): The SageMaker Session to use.
        download (bool): If True, downloads the metric CSV from S3 and saves to local_path.
        local_path (str): The local path where the metric CSV should be downloaded to.
    """
    response = session.sagemaker_client.describe_inference_recommendations_job(JobName=job_name)
    if "OutputConfig" in response.keys() and "BenchmarkResultsOutputConfig" in response.get(
        "OutputConfig"
    ):
        location = response.get("OutputConfig")["BenchmarkResultsOutputConfig"]["S3OutputUri"]
        if not download:
            return location
        bucket_name, key_prefix = location.split("s3://")[1].split("/", 1)
        return session.download_data(local_path, bucket_name, key_prefix)[0]

    raise Exception(
        "No concurrency-level metric CSV found for this benchmark. Detailed metrics are only "
        + "available for benchmarks using the `Concurrencies` traffic type."
    )
