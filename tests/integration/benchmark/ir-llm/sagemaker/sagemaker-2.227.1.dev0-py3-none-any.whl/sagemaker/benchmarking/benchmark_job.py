# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Holds the BenchmarkJob class."""
from __future__ import absolute_import

import datetime
import operator
import tempfile
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Union
import pandas as pd
from IPython.display import display

from sagemaker import Session
from sagemaker.benchmarking.benchmark import InferenceBenchmark
from sagemaker.benchmarking.traffic_pattern_config import TrafficPatternConfig
from sagemaker.benchmarking.constants import COLUMN_PREFIXES_TO_TRIM
from sagemaker.benchmarking.utils import get_benchmarks_output_csv

logger = LOGGER = logging.getLogger(__name__)


@dataclass
class BenchmarkJob:
    """A benchmark job which contains one or more InferenceBenchmarks.

    Args:
        benchmarks (List[InferenceBenchmark]): The benchmarks created by this job.
        creation_time (datetime): A timestamp that shows when this job was created.
        job_name (str): The name which identifies this job.
        model_name (str): The name of the model used by this job for benchmarking.
        stopping_conditions (Dict[str, Union[int, str]]): The stopping conditions used for
            the benchmarks.
        traffic_pattern (TrafficPatternConfig): The traffic pattern used for the benchmarks.
        role_arn (str): The AWS IAM role used to create Amazon SageMaker endpoints.
        sagemaker_session (Session): A SageMaker Session object used for SageMaker interactions.
            If not specified, one is created using the default AWS configuration chain.
    """

    benchmarks: List[InferenceBenchmark] = field(
        default=None,
        metadata={"help": "The benchmarks created by this job"},
    )
    creation_time: Optional[datetime.datetime] = field(
        default=None,
        metadata={"help": "A timestamp that shows when this job was created"},
    )
    job_name: Optional[str] = field(
        default=None, metadata={"help": "The name which identifies this job"}
    )
    model_name: Optional[str] = field(
        default=None,
        metadata={"help": "The name of the model used by this job for benchmarking"},
    )
    stopping_conditions: Optional[Dict[str, Union[int, str]]] = field(
        default=None,
        metadata={"help": "Defines the stopping conditions for the benchmarks"},
    )
    traffic_pattern: Optional[TrafficPatternConfig] = field(
        default=None,
        metadata={"help": "Defines the traffic pattern for the benchmarks"},
    )
    role_arn: Optional[str] = field(
        default=None, metadata={"help": "Define the role for the endpoint"}
    )
    sagemaker_session: Optional[Session] = field(
        default=None, metadata={"help": "Define sagemaker session for execution"}
    )

    def detailed_metrics_df(self) -> pd.DataFrame:
        """Returns a dataframe with concurrency-level metrics for all InferenceBenchmarks."""
        tmp_dir = tempfile.TemporaryDirectory()
        benchmark_results_output_location = get_benchmarks_output_csv(
            job_name=self.job_name,
            session=self.sagemaker_session,
            download=True,
            local_path=tmp_dir.name,
        )
        df = pd.read_csv(benchmark_results_output_location)
        tmp_dir.cleanup()
        df.columns = df.columns.str.replace("RecommendationId", "BenchmarkId")
        df.rename(columns=lambda x: x[0].upper() + x[1:], inplace=True)
        return df.sort_values(by="Concurrency")

    def detailed_metrics_dicts(self) -> List[Dict[str, str]]:
        """Returns a list of dicts with concurrency-level metrics for all InferenceBenchmarks."""
        if not self.benchmarks:
            self._populate_benchmarks()

        return [bm.detailed_metrics_dict() for bm in self.benchmarks]

    def key_metrics_df(self) -> pd.DataFrame:
        """Returns a dataframe with max concurrency level metrics for all InferenceBenchmarks."""
        if not self.benchmarks:
            self._populate_benchmarks()

        dfs = [benchmark.key_metrics_df() for benchmark in self.benchmarks]
        df = pd.concat(dfs)
        df.columns = df.columns.str.replace(COLUMN_PREFIXES_TO_TRIM, "", regex=True)
        return df

    def key_metrics_dicts(self) -> List[Dict]:
        """Returns a list of dicts with max concurrency level metrics for

        all InferenceBenchmarks.
        """
        if not self.benchmarks:
            self._populate_benchmarks()

        return [benchmark.key_metrics_dict() for benchmark in self.benchmarks]

    def get_benchmark(self, benchmark_id) -> InferenceBenchmark:
        """Returns an InferenceBenchmark in this job.

        Args:
            benchmark_id (str): Id of the benchmark in this job to return.
        """
        if not self.benchmarks:
            self._populate_benchmarks()

        for benchmark in self.benchmarks:
            if benchmark.benchmark_id == benchmark_id:
                return benchmark
        raise Exception(f"Benchmark with benchmarkId {benchmark_id} not found.")

    def get_benchmark_results_csv_path(
        self, download: Optional[bool] = False, local_path: Optional[str] = "."
    ) -> str:
        """Returns the S3 URI of the concurrency-level metrics CSV, or

        downloads it and returns the local path.

        Args:
            download (bool): If True, downloads the metric CSV from S3 and saves to local_path.
            local_path (str): The local path where the metric CSV should be downloaded to.
        """
        return get_benchmarks_output_csv(
            job_name=self.job_name,
            session=self.sagemaker_session,
            download=download,
            local_path=local_path,
        )

    def get_status(self) -> str:
        """Returns the current status of the InferenceBenchmarkJob."""
        try:
            response = (
                self.sagemaker_session.sagemaker_client.describe_inference_recommendations_job(
                    JobName=self.job_name
                )
            )
            if response.get("FailureReason"):
                return f"{response.get('Status')}: {response.get('FailureReason')}"
            return response["Status"]
        except Exception as e:
            raise Exception("Encountered error getting the job status.") from e

    def list_benchmarks(
        self,
        metric_values_less_than: Dict[str, float] = None,
        metric_values_greater_than: Dict[str, float] = None,
        quiet: bool = False,
    ) -> List[InferenceBenchmark]:
        """Returns a DataFrame of InferenceBenchmarks in this InferenceBenchmarkJob.

        Args:
            metric_values_less_than (Dict): Map of metric names and threshold values. Only
                benchmarks which have metrics satisfying these criteria will be returned.
            metric_values_greater_than (Dict): Map of metric names and threshold values. Only
                benchmarks which have metrics satisfying these criteria will be returned.
            quiet (bool): If True, displays a dataframe of the listed benchmarks. Default is False.
        """
        if not self.benchmarks:
            self._populate_benchmarks()

        # Return all benchmarks if no filters are set
        if not metric_values_less_than and not metric_values_greater_than:
            if not quiet:
                display(self._to_metrics_as_df(self.benchmarks))
            return self.benchmarks

        # Process less-than metric thresholds
        less_than_results = [
            benchmark
            for benchmark in self.benchmarks
            if self._filter_by_metrics(benchmark, metric_values_less_than, operator.lt)
        ]

        if not metric_values_greater_than:
            if not quiet:
                display(self._to_metrics_as_df(less_than_results))
            return less_than_results

        # Process greater-than metric thresholds against less_than_results
        greater_than_results = [
            benchmark
            for benchmark in less_than_results
            if self._filter_by_metrics(benchmark, metric_values_greater_than, operator.gt)
        ]
        if not quiet:
            display(self._to_metrics_as_df(greater_than_results))
        return greater_than_results

    def stop(self):
        """Stops this InferenceBenchmarkJob."""
        try:
            self.sagemaker_session.sagemaker_client.stop_inference_recommendations_job(
                JobName=self.job_name
            )
            logger.info("%s successfully stopped.", self.job_name)
        except Exception as e:
            raise Exception("Encountered error stopping the job.") from e

    def wait(self, log_level: str = "Verbose"):
        """Waits for the InferenceBenchmarkJob to complete.

        Args:
            log_level (str): The level of verbosity for the logs.
                Can be "Quiet" or "Verbose" (default: "Verbose").

        Returns:
            None

        Raises:
            exceptions.CapacityError: If the job fails with CapacityError.
            exceptions.UnexpectedStatusException: If the job fails.
        """
        self.sagemaker_session.wait_for_inference_recommendations_job(
            job_name=self.job_name, log_level=log_level
        )
        if not self.benchmarks:
            logger.info("Job has completed, populating benchmarks.")
            self._populate_benchmarks()

    def _as_dict(self) -> Dict:
        """Returns this job as a Python dictionary, omitting sagemaker_session and role_arn

        attributes for readability.

        Returns:
            Dict
        """
        return {
            "JobName": self.job_name,
            "Status": self.get_status(),
            "CreationTime": self.creation_time,
            "ModelName": self.model_name,
            "StoppingConditions": self.stopping_conditions,
            "TrafficPattern": self.traffic_pattern,
            "Benchmarks": len(self.benchmarks),
        }

    def _populate_benchmarks(self):
        """Populates this job's benchmarks by retrieving inference recommendations job results

        from Amazon SageMaker and converting them into InferenceBenchmark objects.

        Returns:
            None

        Raises:
            botocore.exceptions.ClientError: If there is an error when retrieving
                the job results from SageMaker.
        """
        benchmark_job_results = (
            self.sagemaker_session.sagemaker_client.describe_inference_recommendations_job(
                JobName=self.job_name
            )
        )
        self.benchmarks = self._convert_benchmark_job_results_to_benchmarks(benchmark_job_results)
        if not self.benchmarks:
            raise Exception(
                "No completed benchmarks found for this job. If the job is still in progress "
                + "please wait until it completes."
            )

    def _convert_benchmark_job_results_to_benchmarks(
        self, benchmark_job_results
    ) -> List[InferenceBenchmark]:
        """Converts a list of InferenceRecommendations into InferenceBenchmark objects.

        Args:
            benchmark_job_results (Dict): Response from DescribeInferenceRecommendationsJob API.
        """
        return [
            InferenceBenchmark(
                role_arn=self.role_arn,
                sagemaker_session=self.sagemaker_session,
                benchmark_id=benchmark.get("RecommendationId"),
                endpoint_config=benchmark.get("EndpointConfiguration"),
                metrics=benchmark.get("Metrics"),
                model_name=self.model_name,
                model_configuration=benchmark.get("ModelConfiguration"),
                invocation_end_time=benchmark.get("InvocationEndTime"),
                invocation_start_time=benchmark.get("InvocationStartTime"),
            )
            for benchmark in benchmark_job_results.get("InferenceRecommendations", [])
        ]

    def _to_metrics_as_df(self, benchmarks) -> pd.DataFrame:
        """Returns a DataFrame from a list of InferenceBenchmarks.

        Args:
            benchmarks (List[InferenceBenchmark]): InferenceBenchmarks to convert.
        """
        if benchmarks:
            listed_jobs_df = pd.concat(
                [benchmark.key_metrics_df() for benchmark in benchmarks],
                ignore_index=True,
            )
            return listed_jobs_df
        logger.info("No benchmarks found.")
        return None

    def _filter_by_metrics(self, benchmark, metric_thresholds, operation):
        """Return True if metric value satisfies given operator, or

        if no metric_thresholds are given
        """
        return (
            all(
                benchmark.metrics.get(metric) and operation(benchmark.metrics[metric], value)
                for metric, value in metric_thresholds.items()
            )
            if metric_thresholds
            else True
        )
