# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Defines various preset traffic pattern configurations."""
from __future__ import absolute_import

from sagemaker.inference_recommender.inference_recommender_mixin import (
    Concurrency,
)
from sagemaker.benchmarking.traffic_pattern_config import TrafficPatternConfig

SYNCHRONOUS_INVOCATION_TYPE = {"InvocationType": "InvokeEndpoint"}
STREAMING_INVOCATION_TYPE = {"InvocationType": "InvokeEndpointWithResponseStream"}


class PresetTrafficPattern:
    """Class containing preset traffic patterns."""

    SINGLE_USER = [
        Concurrency(duration_in_seconds=120, concurrent_users=1),
        Concurrency(duration_in_seconds=120, concurrent_users=1),
    ]

    LINEAR_GROWTH = [
        Concurrency(duration_in_seconds=120, concurrent_users=users)
        for users in [i * 3 for i in range(1, 4)]
    ]

    LOGISTIC_GROWTH = [
        Concurrency(duration_in_seconds=240, concurrent_users=1),
        Concurrency(duration_in_seconds=240, concurrent_users=2),
        Concurrency(duration_in_seconds=240, concurrent_users=4),
        Concurrency(duration_in_seconds=240, concurrent_users=8),
        Concurrency(duration_in_seconds=240, concurrent_users=16),
        Concurrency(duration_in_seconds=240, concurrent_users=32),
        Concurrency(duration_in_seconds=240, concurrent_users=64),
        Concurrency(duration_in_seconds=240, concurrent_users=128),
        Concurrency(duration_in_seconds=240, concurrent_users=256),
        Concurrency(duration_in_seconds=240, concurrent_users=512),
        Concurrency(duration_in_seconds=240, concurrent_users=768),
        Concurrency(duration_in_seconds=240, concurrent_users=1024),
        Concurrency(duration_in_seconds=240, concurrent_users=1280),
        Concurrency(duration_in_seconds=240, concurrent_users=1536),
        Concurrency(duration_in_seconds=240, concurrent_users=1792),
        Concurrency(duration_in_seconds=240, concurrent_users=2048),
    ]


class PresetTrafficPatternConfig:
    """Class containing preset traffic pattern configs. Includes invocation type and traffic patterns."""

    LOGISTIC_GROWTH_STREAMING = TrafficPatternConfig(
        traffic_pattern=PresetTrafficPattern.LOGISTIC_GROWTH,
        inference_invocation_types=STREAMING_INVOCATION_TYPE,
    )

    SINGLE_USER_SYNCHRONOUS = TrafficPatternConfig(traffic_pattern=PresetTrafficPattern.SINGLE_USER)
