#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Defines the Methodology class."""
from __future__ import absolute_import

from dataclasses import dataclass, field
from typing import Dict

from sagemaker.benchmarking.traffic_pattern_config import TrafficPatternConfig


@dataclass
class Methodology:
    """A predefined set of workload configurations to use in a benchmark job."""

    stopping_conditions: Dict = field(
        default=None, metadata={"help": "Defines the stopping conditions"}
    )
    traffic_pattern: TrafficPatternConfig = field(
        default=None, metadata={"help": "Defines the traffic pattern"}
    )
    tokenizer_config: Dict = field(
        default=None,
        metadata={"help": "Defines the tokenizer config"},
    )

    def get_stopping_conditions(self):
        """Returns the stopping conditions."""
        return self.stopping_conditions or {}

    def get_traffic_pattern(self):
        """Returns the traffic pattern."""
        return self.traffic_pattern or None

    def get_tokenizer_config(self):
        """Returns the tokenizer config."""
        return self.tokenizer_config or {}
