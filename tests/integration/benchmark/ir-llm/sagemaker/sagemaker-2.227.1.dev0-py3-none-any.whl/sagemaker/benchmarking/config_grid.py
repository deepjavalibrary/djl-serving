# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Holds the ConfigGrid class."""
from __future__ import absolute_import

from math import prod
from typing import List, Dict, Optional
from dataclasses import dataclass


@dataclass
class ConfigGrid:
    """Defines the instance and env param configurations for a benchmark.

    Args:
        instance_type (str): The instance type to use in the benchmark.
        env_params (Dict[str, List[str]]): Environment parameters to benchmark against.
    """

    instance_type: str
    env_params: Optional[Dict[str, List[str]]] = None

    def _to_endpoint_config(self):
        """Converts this ConfigGrid to EndpointConfig json."""

        endpoint_config = {
            "InstanceType": self.instance_type,
        }

        if self.env_params:
            endpoint_config["EnvironmentParameterRanges"] = {
                "CategoricalParameterRanges": [
                    {"Name": k, "Value": v} for k, v in self.env_params.items()
                ]
            }

        return endpoint_config

    def get_number_of_benchmarks(self) -> int:
        """Returns the number of endpoints this ConfigGrid will create."""
        if self.env_params:
            return prod(len(v) for v in self.env_params.values() if len(v) > 1)
        return 1
