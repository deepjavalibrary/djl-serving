# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Holds the configurations for the Benchmarking module."""
from __future__ import absolute_import
import logging
import pandas as pd
from sagemaker.benchmarking.benchmarker import Benchmarker
from sagemaker.benchmarking.config_grid import ConfigGrid
from sagemaker.benchmarking.preset.benchmarks.methodology import Methodology
from sagemaker.benchmarking.preset.stopping_conditions import PresetStoppingConditions
from sagemaker.benchmarking.traffic_pattern_config import TrafficPatternConfig
from sagemaker.benchmarking.preset.traffic_pattern import PresetTrafficPatternConfig
from sagemaker.benchmarking.payload.sample_payload_uploader import SamplePayloadUploader

__all__ = (
    "Benchmarker",
    "ConfigGrid",
    "Methodology",
    "PresetStoppingConditions",
    "TrafficPatternConfig",
    "PresetTrafficPatternConfig",
    "SamplePayloadUploader",
)


pd.set_option("display.max_rows", 500)
pd.set_option("display.max_columns", 500)
pd.set_option("display.width", 150)
pd.set_option("display.max_colwidth", None)

logger = logging.getLogger(__name__)
logger.propagate = False
logger.setLevel(logging.DEBUG)
streamHandler = logging.StreamHandler()
streamHandler.setFormatter(logging.Formatter("[Benchmarker][%(levelname)s] %(message)s"))
logger.addHandler(streamHandler)
