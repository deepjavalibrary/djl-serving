# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Holds the Benchmarker class."""
from __future__ import absolute_import

import logging
import datetime
from typing import List, Dict, Optional, Union
from dataclasses import dataclass, field
import math
import pandas as pd
from IPython.display import display

from sagemaker.benchmarking.benchmark_job import BenchmarkJob
from sagemaker.benchmarking.benchmark import InferenceBenchmark
from sagemaker.benchmarking.constants import (
    MAX_NUM_TESTS,
    MAX_PARALLEL_TESTS,
    SAGEMAKER_SETUP_BUFFER,
    SAGEMAKER_LLM_SETUP_BUFFER,
)
from sagemaker.benchmarking.preset.traffic_pattern import PresetTrafficPatternConfig
from sagemaker.benchmarking.preset.stopping_conditions import PresetStoppingConditions
from sagemaker.benchmarking.traffic_pattern_config import TrafficPatternConfig
from sagemaker.benchmarking.preset.benchmarks.methodology import Methodology
from sagemaker.benchmarking.preset.benchmarks.llm import OPEN_ORCA_2500_PARAMETERS
from sagemaker.benchmarking.config_grid import ConfigGrid
from sagemaker.inference_recommender.inference_recommender_mixin import (
    InferenceRecommenderMixin,
)
from sagemaker.model import Model
from sagemaker import Session
from sagemaker.session import get_execution_role

logger = LOGGER = logging.getLogger(__name__)


@dataclass
class Benchmarker(InferenceRecommenderMixin):
    """Class that creates and manages BenchmarkJobs.

    Args:
        role_arn (Optional[str]): The AWS IAM role to use in the benchmark.
        sagemaker_session (Session): A SageMaker Session object used for SageMaker interactions.
            If not specified, one is created using the default AWS configuration chain.
        preset_benchmark (Optional[Methodology]): A preset methodology to use
            for new benchmark jobs. A Methodology typically defines at least a preset
            traffic pattern config and stopping conditions.
    """

    role_arn: Optional[str] = field(
        default=None, metadata={"help": "Define the role for the endpoint"}
    )
    sagemaker_session: Optional[Session] = field(
        default=None, metadata={"help": "Define sagemaker session for execution"}
    )
    preset_benchmark: Optional[Methodology] = field(
        default=None,
        metadata={"help": "Define the preset methodology to use for new benchmark jobs"},
    )

    def _convert_config_grid_to_endpoint_configs(
        self, config_grids: List[ConfigGrid]
    ) -> List[Dict]:
        """Converts ConfigGrid objects to endpoint configs.

        Args:
            config_grids (List[ConfigGrid]): List of ConfigGrids to convert.
        """
        return [grid._to_endpoint_config() for grid in config_grids]

    def _stopping_conditions_to_json(self, stopping_conditions):
        """Converts stopping conditions defined as a python dictionary to JSON."""
        return {
            "FlatInvocations": stopping_conditions["FlatInvocations"],
            "MaxInvocations": stopping_conditions["MaxInvocations"],
            "ModelLatencyThresholds": [
                {
                    "Percentile": "P95",
                    "ValueInMilliseconds": stopping_conditions["MaxModelLatencyInMs"],
                }
            ],
        }

    def create_benchmark_job(
        self,
        benchmark_configurations: List[ConfigGrid] = None,
        sample_payload_url: Optional[str] = None,
        role_arn: Optional[str] = None,
        sagemaker_session: Optional[Session] = None,
        job_name: Optional[str] = None,
        job_duration: Optional[int] = None,
        model_name: Optional[str] = None,
        model: Optional[Model] = None,
        benchmark_results_output_config: Optional[Dict[str, str]] = None,
        tokenizer_config: Optional[Dict[str, str]] = None,
        content_type: Optional[str] = None,
        traffic_pattern: Optional[TrafficPatternConfig] = None,
        stopping_conditions: Optional[Dict[str, Union[int, str]]] = None,
    ) -> BenchmarkJob:
        """Creates and returns a BenchmarkJob.

        Args:
            sample_payload_url (str): S3 URI where a tar.gz of sample payloads is stored.
            role_arn (str): The AWS IAM role to use in the benchmark.
            sagemaker_session (Session): The SageMaker session to use for execution.
            job_name (str): The unique name for the job.
            job_duration (int): The max duration for which the job should run.
            model_name (str): The name of the SageMaker model to use in the benchmark job.
            model (Model): A SageMaker Model object to use in the benchmark job.
            benchmark_configurations (List[ConfigGrid]): A list of instance types and env param
                combinations to benchmark.
            benchmark_results_output_config (Dict): An S3 location to store CSVs containing
                concurrency-level metrics, emitted by jobs using the Concurrency traffic pattern.
            tokenizer_config (Dict): Configuration for a tokenizer to use for calculating
                token-level metrics in the benchmark job.
            traffic_pattern (TrafficPatternConfig): The traffic pattern to use in the benchmark job.
            stopping_conditions (Dict): The conditions under which the job should stop.
            content_type (str): The MIME type of the input data in the payload request body.
        """
        self.sagemaker_session = sagemaker_session or self.sagemaker_session or Session()
        self.role_arn = role_arn or self.role_arn or get_execution_role(self.sagemaker_session)

        # Process any Methodology set on the Benchmarker
        # Explicitly-set values take precedence over those on the Methodology
        if self.preset_benchmark:
            tokenizer_config = tokenizer_config or self.preset_benchmark.get_tokenizer_config()
            stopping_conditions = (
                stopping_conditions or self.preset_benchmark.get_stopping_conditions()
            )
            traffic_pattern = traffic_pattern or self.preset_benchmark.get_traffic_pattern()

        # Assign stopping_conditions and traffic_pattern defaults if not set
        if not stopping_conditions:
            logger.info(
                "stopping_conditions was not explicitly set, defaulting to NO_STOPPING_CONDITION."
            )
            stopping_conditions = PresetStoppingConditions.NO_STOPPING_CONDITION

        if not traffic_pattern:
            logger.info(
                "traffic_pattern was not explicitly set, defaulting to LOGISTIC_GROWTH_STREAMING."
            )
            traffic_pattern = PresetTrafficPatternConfig.LOGISTIC_GROWTH_STREAMING

        # Use default sample payload archive if not set
        if not sample_payload_url:
            sample_payload_url = OPEN_ORCA_2500_PARAMETERS.format(
                region=self.sagemaker_session.boto_region_name
            )
            logger.info(
                "sample_payload_url was not explicitly set, defaulting to %s.", sample_payload_url
            )

        # Use Session() default bucket if using Concurrency traffic pattern
        # and no output config location is set
        if traffic_pattern.traffic_type == "CONCURRENCIES" and not benchmark_results_output_config:
            benchmark_results_output_config = {
                "S3OutputUri": "s3://" + self.sagemaker_session.default_bucket()
            }
            logger.info(
                "benchmark_results_output_config was not explicitly set, defaulting to %s.",
                benchmark_results_output_config,
            )

        # If job duration is not set, use traffic duration + SM platform setup buffer
        # Buffer is longer if a tokenizer is present; assumes an LLM is being benchmarked
        if not job_duration:
            # Calculate the number of cycles required to run all benchmarks being created.
            # MAX_PARALLEL_TESTS is 5, so for example if 6-10 benchmarks are defined the entire job
            # will require 2 cycles. If only 1-5 tests are defined, all jobs can run in parallel
            # and complete in 1 single cycle.
            total_number_of_benchmarks = 0
            for config_grid in benchmark_configurations:
                total_number_of_benchmarks += config_grid.get_number_of_benchmarks()
            number_of_cycles = math.ceil(total_number_of_benchmarks / MAX_PARALLEL_TESTS)

            # Multiply the benchmark job's traffic duration by the number of cycles required
            job_duration = traffic_pattern.traffic_duration * number_of_cycles
            job_duration += (
                SAGEMAKER_LLM_SETUP_BUFFER if tokenizer_config else SAGEMAKER_SETUP_BUFFER
            )

            logger.info("job_duration was not explicitly set, defaulting to %s.", job_duration)

        # Input Validations
        if not model_name and not model:
            raise ValueError(
                "Either `model_name` or `model` must be set to create a benchmark job."
            )
        if model_name and model:
            raise ValueError(
                "Only one of `model_name` and `model` can be set to create a benchmark job."
            )
        content_type = [content_type] if content_type else None

        if model:
            model.create(
                accept_eula=(
                    tokenizer_config.get("AcceptEula", False) if tokenizer_config else False
                )
            )
            model_name = model.name

        self.sagemaker_session.create_inference_recommendations_job(
            role=self.role_arn,
            sample_payload_url=sample_payload_url,
            supported_content_types=content_type,
            job_name=job_name,
            job_type="Advanced",
            job_duration_in_seconds=job_duration,
            model_name=model_name,
            model_package_version_arn=getattr(model, "model_package_arn", None),
            endpoint_configurations=self._convert_config_grid_to_endpoint_configs(
                benchmark_configurations
            ),
            benchmark_results_output_config=benchmark_results_output_config,
            tokenizer_config=tokenizer_config,
            traffic_pattern=traffic_pattern.to_json,
            stopping_conditions=self._stopping_conditions_to_json(stopping_conditions),
            resource_limit={
                "MaxNumberOfTests": MAX_NUM_TESTS,
                "MaxParallelOfTests": MAX_PARALLEL_TESTS,
            },
        )

        return self.get_benchmark_job(job_name)

    def get_benchmark_job(self, job_name: str = None):
        """Returns a BenchmarkJob given a job name.

        Args:
            job_name (str): The name of a BenchmarkJob.
        """
        self.sagemaker_session = self.sagemaker_session or Session()
        describe_response = (
            self.sagemaker_session.sagemaker_client.describe_inference_recommendations_job(
                JobName=job_name
            )
        )
        benchmark_job = BenchmarkJob(
            role_arn=self.role_arn,
            sagemaker_session=self.sagemaker_session,
            creation_time=describe_response.get("CreationTime"),
            job_name=describe_response.get("JobName"),
            model_name=describe_response.get("InputConfig").get("ModelName"),
            traffic_pattern=describe_response.get("InputConfig").get("TrafficPattern"),
            stopping_conditions=describe_response.get("StoppingConditions"),
        )
        benchmark_job.benchmarks = benchmark_job._convert_benchmark_job_results_to_benchmarks(
            describe_response
        )
        return benchmark_job

    def list_benchmark_jobs(
        self,
        creation_time_after: datetime = None,
        creation_time_before: datetime = None,
        last_modified_time_after: datetime = None,
        last_modified_time_before: datetime = None,
        name_contains: str = None,
        status_equals: str = None,
        sort_by: str = None,
        sort_order: str = None,
        max_results: int = None,
        model_name_equals: str = None,
        model_pkg_version_arn_equals: str = None,
    ) -> List[BenchmarkJob]:
        """Returns a DataFrame of BenchmarkJobs in the account.

        Args:
            creation_time_after (datetime): A filter that returns only jobs created after
                the specified time.
            creation_time_before (datetime): A filter that returns only jobs created before
                the specified time.
            last_modified_time_after: (datetime): A filter that returns only jobs that were
                last modified after the specified time.
            last_modified_time_before (datetime): A filter that returns only jobs that were
                last modified before the specified time.
            name_contains (str): A filter that returns only jobs whose name contains the
                specified string.
            status_equals (str): A filter that returns only jobs with the specified status.
            sort_by (str): The parameter by which to sort the results. Valid values are
                'Name'|'CreationTime'|'Status'.
            sort_order (str): The sort order for the results. Valid values are
                'Ascending'|'Descending'.
            max_results (int): The maximum number of jobs to return.
            model_name_equals (str): A filter that returns jobs created with the specified model.
            model_pkg_version_arn_equals (str): A filter that returns only jobs created
                with the specified model package version.
        """
        self.sagemaker_session = self.sagemaker_session or Session()

        # Construct argument dictionary with non-None values
        arguments = {
            "CreationTimeAfter": creation_time_after,
            "CreationTimeBefore": creation_time_before,
            "LastModifiedTimeAfter": last_modified_time_after,
            "LastModifiedTimeBefore": last_modified_time_before,
            "NameContains": name_contains,
            "StatusEquals": status_equals,
            "SortBy": sort_by,
            "SortOrder": sort_order,
            "MaxResults": max_results,
            "ModelNameEquals": model_name_equals,
            "ModelPackageVersionArnEquals": model_pkg_version_arn_equals,
        }
        # Filter out None values
        filtered_arguments = {k: v for k, v in arguments.items() if v is not None}

        # Call list_inference_recommendations_jobs with filtered arguments
        listed_jobs = self.sagemaker_session.sagemaker_client.list_inference_recommendations_jobs(
            **filtered_arguments
        )

        listed_jobs_df = pd.DataFrame(
            [
                self.get_benchmark_job(job_name=job["JobName"])._as_dict()
                for job in listed_jobs.get("InferenceRecommendationsJobs", [])
            ]
        )
        display(listed_jobs_df)

        return [
            self.get_benchmark_job(job["JobName"])
            for job in listed_jobs.get("InferenceRecommendationsJobs", [])
        ]

    def compare_benchmarks(
        self,
        benchmarks: List[InferenceBenchmark] = None,
        benchmark_ids: List[str] = None,
        benchmark_jobs: List[BenchmarkJob] = None,
        benchmark_job_names: List[str] = None,
        metric_names: List[str] = None,
        metrics_only: bool = False,
        detailed_metrics: bool = False,
    ) -> pd.DataFrame:
        """Compares metrics and configurations from one or more InferenceBenchmarks.

        Args:
            benchmarks (List[InferenceBenchmark]): List of benchmarks to include in the comparison.
            benchmark_ids (List[str]): List of IDs of benchmarks to include in the comparison.
            benchmark_jobs (List[BenchmarkJob]): List of benchmark jobs. All benchmarks in the jobs
                will be included in the comparison.
            benchmark_job_names (List[str]): List of benchmark job names. All benchmarks in the
                associatedjobs will be included in the comparison.
            metric_names (List[str]): List of metric names to compare. By default,
                all metrics are shown.
            metrics_only (bool): If True, includes only benchmark ID and metric columns.
            detailed_metrics (bool): If True, compares concurrency-level metrics. All benchmarks
                compared must have emitted concurrency-level metrics.
        """
        benchmarks = [] if not benchmarks else benchmarks
        benchmark_ids = [] if not benchmark_ids else benchmark_ids
        benchmark_jobs = [] if not benchmark_jobs else benchmark_jobs
        benchmark_job_names = [] if not benchmark_job_names else benchmark_job_names
        metric_names = [] if not metric_names else metric_names

        if not any([benchmarks, benchmark_ids, benchmark_jobs, benchmark_job_names]):
            raise ValueError("No benchmarks to compare.")

        # Aggregate all the benchmarks to compare
        benchmarks_to_compare = benchmarks.copy()
        benchmarks_to_compare.extend(
            [
                self.get_benchmark_job(job_name=id.split("/")[0]).get_benchmark(benchmark_id=id)
                for id in benchmark_ids
            ]
        )
        for job in benchmark_jobs:
            benchmarks_to_compare.extend(job.list_benchmarks(quiet=True))

        for job_name in benchmark_job_names:
            benchmarks_to_compare.extend(
                self.get_benchmark_job(job_name=job_name).list_benchmarks(quiet=True)
            )

        dataframes = []
        for benchmark in benchmarks_to_compare:
            # Choose whether to use detailed or key metrics
            metric_df = (
                benchmark.detailed_metrics_df() if detailed_metrics else benchmark.key_metrics_df()
            )

            # Filter columns for explicitly-specified metric names
            if len(metric_names) > 0:
                columns_to_keep = [
                    "BenchmarkId",
                    "EndpointName",
                    "InstanceType",
                ] + metric_names
                for col_name in columns_to_keep:
                    if col_name not in metric_df.columns:
                        metric_df[col_name] = pd.Series(dtype=float)

                metric_df = metric_df[columns_to_keep]

            # Filter columns to include only BenchmarkId + metrics if metrics_only is True
            if metrics_only:
                columns_to_drop = [
                    "EndpointName",
                    "InstanceType",
                    "ModelName",
                    "InvocationStartTime",
                    "InvocationEndTime",
                    "VariantName",
                    "InitialInstanceCount",
                ]
                metric_df = metric_df[metric_df.columns.difference(columns_to_drop, sort=False)]

            dataframes.append(metric_df)

        # Concat dataframes on columns axis
        return pd.concat(dataframes, axis=0, ignore_index=True).drop_duplicates()
