#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Defines the TrafficPatternConfig class."""
from __future__ import absolute_import

from typing import List, Dict, Union, Optional
from sagemaker.inference_recommender.inference_recommender_mixin import (
    Phase,
    Stairs,
    Concurrency,
)


class TrafficPatternConfig:
    """Defines the TrafficPatternConfig class.

    Args:
        traffic_pattern (List[Union[Phase, Stairs, Concurrency]]): Defines the traffic pattern of
            the benchmark.
        inference_invocation_types (Dict[str, str]): Defines the invocation type to use during
            the benchmark.
    """

    def __init__(
        self,
        traffic_pattern: List[Union[Phase, Stairs, Concurrency]],
        inference_invocation_types: Optional[Dict[str, str]] = None,
    ):
        traffic_types = {
            Phase: "PHASES",
            Stairs: "STAIRS",
            Concurrency: "CONCURRENCIES",
        }

        # Assign traffic_type based on type of traffic pattern provided
        # I.e. traffic_type="PHASES" if traffic_pattern list contains Phase objects
        self.traffic_type = next(
            (
                traffic_types[pattern_type]
                for pattern_type in (Phase, Stairs, Concurrency)
                if any(isinstance(element, pattern_type) for element in traffic_pattern)
            ),
            None,
        )

        if self.traffic_type:
            to_json = {
                "TrafficType": self.traffic_type,
                self.traffic_type.capitalize(): [pattern.to_json for pattern in traffic_pattern],
            }

            if inference_invocation_types:
                to_json["InferenceInvocationTypes"] = inference_invocation_types

            self.to_json = to_json
            self.traffic_duration = sum(
                p.to_json.get("DurationInSeconds", 0) for p in traffic_pattern
            )
        else:
            raise ValueError(
                "Invalid traffic type specified. Valid types are `Phase`, `Stairs`,"
                + " and `Concurrency`."
            )
