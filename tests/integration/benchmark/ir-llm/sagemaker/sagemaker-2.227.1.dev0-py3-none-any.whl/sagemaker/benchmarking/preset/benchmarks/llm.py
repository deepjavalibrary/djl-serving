#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Defines various preset benchmarking methodologies for LLM use cases."""
from __future__ import absolute_import

from .methodology import Methodology
from sagemaker.benchmarking.preset.traffic_pattern import PresetTrafficPatternConfig
from sagemaker.benchmarking.preset.stopping_conditions import PresetStoppingConditions

# Ungated model ID
GPT_NEO_1_3B_MODEL_ID = "EleutherAI/gpt-neo-1.3B"

# Preset sample payload tar archive created from 2500 random OpenOrca entries and request params
OPEN_ORCA_2500_PARAMETERS = (
    "s3://jumpstart-cache-prod-{region}/payloads/openorca/openorca_2500_parameters.tar.gz"
)


class Llm:
    """Preset Methodologies for LLM use cases."""

    THROUGHPUT_LATENCY_CURVE = Methodology(
        stopping_conditions=PresetStoppingConditions.NO_STOPPING_CONDITION,
        traffic_pattern=PresetTrafficPatternConfig.LOGISTIC_GROWTH_STREAMING,
        tokenizer_config={"model_id": GPT_NEO_1_3B_MODEL_ID},
    )
