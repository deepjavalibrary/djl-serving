# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Holds the InferenceBenchmark class."""
from __future__ import absolute_import

from datetime import datetime
from dataclasses import dataclass, field
import logging
import tempfile
import csv
from typing import List, Dict, Optional, Union
import pandas as pd
from sagemaker.predictor import Predictor

from sagemaker import Model, Session
from sagemaker.benchmarking.constants import COLUMN_PREFIXES_TO_TRIM
from sagemaker.benchmarking.utils import get_benchmarks_output_csv

logger = LOGGER = logging.getLogger(__name__)


@dataclass
class InferenceBenchmark:
    """Class definition for an individual benchmark.

    Args:
        benchmark_id (str): The The benchmark ID which uniquely identifies each benchmark.
        endpoint_config (Dict[str, Union[str, int, Dict[str, int]]]): The endpoint
            configuration parameters that were benchmarked.
        metrics (Dict[str, Union[int, float]]): Metrics emitted during the benchmark.
        model_name (str): The name of the model used by this job for benchmarking.
        model_configuration (Dict[str, Union[str, List[Dict[str, str]]]]): Defines the
            model configuration.
        invocation_start_time (datetime): A timestamp that shows when the benchmark started.
        invocation_end_time (datetime): A timestamp that shows when the benchmark completed.
        role_arn (str): The AWS IAM role to use for creating Amazon SageMaker endpoints.
        sagemaker_session (Session): The SageMaker session to use for the execution.
    """

    benchmark_id: Optional[str] = field(
        default=None,
        metadata={"help": "The benchmark ID which uniquely identifies each benchmark"},
    )
    endpoint_config: Optional[Dict[str, Union[str, int, Dict[str, int]]]] = field(
        default=None, metadata={"help": "Defines the endpoint configuration parameters"}
    )
    metrics: Optional[Dict[str, Union[int, float]]] = field(
        default=None, metadata={"help": "Metrics emitted during the benchmark"}
    )
    model_name: Optional[str] = field(
        default=None,
        metadata={"help": "The name of the model used by this job for benchmarking"},
    )
    model_configuration: Optional[Dict[str, Union[str, List[Dict[str, str]]]]] = field(
        default=None, metadata={"help": "Defines the model configuration"}
    )
    invocation_start_time: Optional[datetime] = field(
        default=None,
        metadata={"help": "A timestamp that shows when the benchmark started"},
    )
    invocation_end_time: Optional[datetime] = field(
        default=None,
        metadata={"help": "A timestamp that shows when the benchmark completed"},
    )
    role_arn: Optional[str] = field(
        default=None, metadata={"help": "Define the role for the endpoint"}
    )
    sagemaker_session: Optional[Session] = field(
        default=None, metadata={"help": "Define sagemaker session for execution"}
    )

    def detailed_metrics_df(self) -> pd.DataFrame:
        """Returns a dataframe with metrics at every concurrency level."""
        tmp_dir = tempfile.TemporaryDirectory()
        benchmark_results_output_location = get_benchmarks_output_csv(
            job_name=self.benchmark_id.split("/")[0],
            session=self.sagemaker_session,
            download=True,
            local_path=tmp_dir.name,
        )
        df = pd.read_csv(benchmark_results_output_location)
        tmp_dir.cleanup()
        # Get only rows for this benchmark & capitalize column headers for consistency.
        df = df.loc[df["RecommendationId"] == self.benchmark_id]
        df.columns = df.columns.str.replace("RecommendationId", "BenchmarkId")
        df.rename(columns=lambda x: x[0].upper() + x[1:], inplace=True)
        return df.sort_values(by="Concurrency")

    def detailed_metrics_dict(self) -> List[Dict[str, str]]:
        """Returns a dictionary with metrics at every concurrency level."""
        tmp_dir = tempfile.TemporaryDirectory()
        benchmark_results_output_location = get_benchmarks_output_csv(
            job_name=self.benchmark_id.split("/")[0],
            session=self.sagemaker_session,
            download=True,
            local_path=tmp_dir.name,
        )
        with open(benchmark_results_output_location, "r") as file:
            csv_reader = csv.DictReader(file)
            tmp_dir.cleanup()
            return list(csv_reader)

    def key_metrics_df(self) -> pd.DataFrame:
        """Returns a dataframe with metrics at the max concurrency level."""
        key_metrics = pd.json_normalize(self.key_metrics_dict())
        df = pd.DataFrame.from_dict(key_metrics)
        df.columns = df.columns.str.replace(COLUMN_PREFIXES_TO_TRIM, "", regex=True)
        return df

    def key_metrics_dict(self) -> Dict:
        """Returns a dictionary with metrics at the max concurrency level."""
        return {
            "BenchmarkId": self.benchmark_id,
            "ModelName": self.model_name,
            "EndpointConfig": self.endpoint_config,
            "Metrics": self.metrics,
            "ModelConfiguration": self.model_configuration,
            "InvocationStartTime": self.invocation_start_time,
            "InvocationEndTime": self.invocation_end_time,
        }

    def to_model(
        self,
        role_arn: Optional[str] = None,
        predictor_cls: Optional[Predictor] = Predictor,
    ) -> Model:
        """Creates a Model from this benchmark.

        Args:
            role_arn (str): The AWS IAM role to use for creating Amazon SageMaker endpoints.
            predictor_cls (Predictor): A function to call to create a predictor.
        """
        try:
            response = self.sagemaker_session.describe_model(name=self.model_name)
            if "PrimaryContainer" in response.keys():
                container = response.get("PrimaryContainer")
            elif "Containers" in response.keys():
                if len(response.get("Containers")) > 1:
                    logger.warning(
                        "More than one container found for the model, using the first one."
                    )
                container = response.get("Containers")[0]
            else:
                raise ValueError("No containers defined for model {}".format(self.model_name))

            return Model(
                role=role_arn or self.role_arn,
                image_uri=container.get("Image"),
                model_data=self._get_model_data_location(container=container),
                env=self._convert_model_configuration_to_env(),
                predictor_cls=predictor_cls,
                sagemaker_session=self.sagemaker_session,
            )
        except Exception as e:
            raise Exception("Failed to describe model with name {}".format(self.model_name)) from e

    def _get_model_data_location(self, container: Dict) -> str:
        """Returns S3 location of a container's model data.

        Args:
            container (Dict): Container configuration from DescribeEndpoint() call.
        """
        # ModelDataUrl will only point to compressed tar archives.
        # ModelDataSource can also include compressed artifacts, and defines compression type.
        if container.get("ModelDataUrl"):
            return container.get("ModelDataUrl")

        return container.get("ModelDataSource")

    def _convert_model_configuration_to_env(self) -> Dict[str, str]:
        """Converts model configuration to env params."""
        if self.model_configuration is None:
            return {}

        env_params = {
            e.get("Key"): e.get("Value")
            for e in self.model_configuration.get("EnvironmentParameters", [])
        }
        return env_params
