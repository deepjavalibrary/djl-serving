# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""Holds the SamplePayloadUploader class."""
from __future__ import absolute_import

import io
import os
import json
import tarfile
from sagemaker import Session

DEFAULT_KEY_PREFIX = "payloads"


class SamplePayloadUploader:
    """Class that creates tar archives and uploads them to s3.

    Args:
        bucket_name (str): S3 bucket to upload the payloads.
        sagemaker_session (sagemaker.session.Session): The
            SageMaker session to use for the execution.
    """

    def __init__(self, bucket_name: str = None, sagemaker_session: Session = None):
        self.sagemaker_session = sagemaker_session or Session()
        self.bucket_name = bucket_name or self.sagemaker_session.default_bucket()
        self.archives = []

    def upload_file_to_s3(
        self,
        filepath: str,
        arcname: str = None,
        s3_key_prefix: str = None,
        bucket_name: str = None,
        sagemaker_session: Session = None,
    ):
        """Writes a tar archive file from a single file and uploads it to an S3 bucket.

        Args:
            filepath (str): The filepath of the local file to upload to s3.
            arcname (str): Optional. Name for the archive to be created.
            s3_key_prefix (str): Optional. Key prefix to use when uploading to s3.
            bucket_name (str): Optional. Name of the bucket to upload to. Uses the
                default bucket on the SageMaker Session by default.
            sagemaker_session (Session): Optional. The SageMaker session to use for execution.
        """
        # Check if the file exists
        if not os.path.exists(filepath):
            raise Exception("File {} does not exist.".format(filepath))

        bucket_name = bucket_name or self.bucket_name

        # By default use payload path as base for new tar archive
        # Create the name for the tar.gz archive
        arcname = f"{arcname or filepath}.tar.gz"

        # Add the payload file to the tar archive
        with tarfile.open(arcname, "w:gz") as tar:
            tar.add(filepath, arcname=os.path.basename(filepath))

        print(f"Tar.gz file created from file successfully: {arcname}")
        self.archives.append(arcname)

        session = sagemaker_session or self.sagemaker_session or Session()
        s3_uri = session.upload_data(
            path=arcname,
            bucket=bucket_name or session.default_bucket(),
            key_prefix=s3_key_prefix or DEFAULT_KEY_PREFIX,
        )
        print(f"Tarfile uploaded to S3: {s3_uri}")
        return s3_uri

    def upload_json_to_s3(
        self,
        json_data,
        arcname: str = None,
        s3_key_prefix: str = None,
        bucket_name: str = None,
        sagemaker_session: Session = None,
    ):
        """Writes a tar archive file from JSON and uploads it to an S3 bucket.

        Args:
            json_data (object): The JSON data to upload to s3.
            arcname (str): Optional. Name for the archive to be created.
            s3_key_prefix (str): Optional. Key prefix to use when uploading to s3.
            bucket_name (str): Optional. Name of the bucket to upload to. Uses the
                default bucket on the SageMaker Session by default.
            sagemaker_session (Session): Optional. The SageMaker session to use for execution.
        """
        bucket_name = bucket_name or self.bucket_name

        json_bytes = json.dumps(json_data).encode("utf-8")
        file_obj = io.BytesIO(json_bytes)

        with tarfile.open(arcname, mode="w:gz") as tar:
            info = tarfile.TarInfo(name=f"{arcname}.json")
            info.size = len(json_bytes)
            tar.addfile(info, fileobj=file_obj)

        print(f"Tar.gz file created from JSON successfully: {arcname}")
        self.archives.append(arcname)

        # Upload the tarball content to S3
        session = sagemaker_session or self.sagemaker_session or Session()
        s3_uri = session.upload_data(
            path=arcname,
            bucket=bucket_name or session.default_bucket(),
            key_prefix=s3_key_prefix or DEFAULT_KEY_PREFIX,
        )
        print(f"Tarfile uploaded to S3: {s3_uri}")
        return s3_uri

    def upload_directory_to_s3(
        self,
        directory: str,
        arcname: str = None,
        s3_key_prefix: str = None,
        bucket_name: str = None,
        sagemaker_session: Session = None,
    ):
        """Writes a tar archive file from a directory and uploads it to an S3 bucket.

        Args:
            directory (str): The path of the directory to upload to s3.
            arcname (str): Optional. Name for the archive to be created.
            s3_key_prefix (str): Optional. Key prefix to use when uploading to s3.
            bucket_name (str): Optional. Name of the bucket to upload to. Uses the
                default bucket on the SageMaker Session by default.
            sagemaker_session (Session): Optional. The SageMaker session to use for execution.
        """
        bucket_name = bucket_name or self.bucket_name
        # By default use payload path as base for new tar archive
        # Create the name for the tar.gz archive
        arcname = f"{arcname or os.path.basename(directory)}.tar.gz"

        with tarfile.open(arcname, mode="w:gz") as tar:
            for root, _, files in os.walk(directory):
                for file in files:
                    file_path = os.path.join(root, file)
                    tar.add(file_path, arcname=os.path.relpath(file_path, directory))
        print(f"Tar.gz file created from directory successfully: {arcname}")
        self.archives.append(arcname)

        session = sagemaker_session or self.sagemaker_session or Session()
        s3_uri = session.upload_data(
            path=arcname,
            bucket=bucket_name or session.default_bucket(),
            key_prefix=s3_key_prefix or DEFAULT_KEY_PREFIX,
        )
        print(f"Tarfile uploaded to S3: {s3_uri}")
        return s3_uri

    def cleanup(self):
        """Deletes all local files created by this instance of SamplePayloadUploader."""
        print("Deleting " + str(self.archives) + " local archives.")
        for archive in self.archives:
            print("Deleting " + archive)
            os.remove(archive)
        print("All local archives deleted.")
